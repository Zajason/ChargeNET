UML Requirements code
@startuml
skinparam handwritten false
skinparam shadow false
hide circle
hide empty members
left to right direction

skinparam class {
    BackgroundColor<<Root>> #DDDDDD
    BorderColor<<Root>> Black
    
    BackgroundColor<<Functional>> #E3F2FD
    BorderColor<<Functional>> #1565C0
    
    BackgroundColor<<Financial>> #E8F5E9
    BorderColor<<Financial>> #2E7D32
    
    BackgroundColor<<Technical>> #FFF3E0
    BorderColor<<Technical>> #E65100
    
    BackgroundColor<<NonFunctional>> #FCE4EC
    BorderColor<<NonFunctional>> #880E4F
    
    ArrowColor #555555
}

class "<b>ChargeNet System</b>\n(System Specification)" as ROOT <<Root>>

class "<b>Functional Requirements</b>" as G_FUNC <<Functional>>
ROOT +-- G_FUNC

class "<b>User & App Features</b>" as R_USER <<Functional>>
G_FUNC +-- R_USER

class "<b>Account Management</b>" as R_ACC <<Functional>> {
    Registration, Profile Data, Preferences
}
R_USER +-- R_ACC

class "<b>Map & Discovery</b>" as R_MAP <<Functional>> {
    View Chargers, Filter by Type/Power
}
R_USER +-- R_MAP

class "<b>Real-Time Status</b>" as R_STATUS <<Functional>> {
    Show Available / Occupied / Out-of-Order
}
R_MAP +-- R_STATUS

class "<b>Reservation Logic</b>" as R_RES <<Functional>>
G_FUNC +-- R_RES

class "<b>Booking Rules</b>" as R_BOOK <<Functional>> {
    Reserve for 30 mins, Max 60 mins
}
R_RES +-- R_BOOK

class "<b>Exclusivity Lock</b>" as R_LOCK <<Functional>> {
    Only the booker can unlock the charger
}
R_RES +-- R_LOCK

class "<b>Charging Session</b>" as R_SESS <<Functional>>
G_FUNC +-- R_SESS

class "<b>Session Control</b>" as R_CTRL <<Functional>> {
    Start, Live Monitoring (kWh/Cost)
}
R_SESS +-- R_CTRL

class "<b>Stop Conditions</b>" as R_STOP <<Functional>> {
    Auto-Stop (Battery Full/Funds Out)
    Manual Stop (User App)
}
R_SESS +-- R_STOP

class "<b>Financial Requirements</b>" as G_FIN <<Financial>>
ROOT +-- G_FIN

class "<b>Pricing Logic</b>" as R_PRICE <<Financial>> {
    Dynamic Price (Time, Location, Load)
}
G_FIN +-- R_PRICE

class "<b>Payment Process</b>" as R_PAY <<Financial>> {
    Pre-Authorization (Hold Funds)
    Final Settlement (Release Hold)
}
G_FIN +-- R_PAY

class "<b>Billing History</b>" as R_HIST <<Financial>> {
    6-Month History & PDF Invoices
}
G_FIN +-- R_HIST

class "<b>Provider Operations</b>" as G_OPS <<Technical>>
ROOT +-- G_OPS

class "<b>Admin CLI</b>" as R_CLI <<Technical>> {
    Command Line Interface for Management
}
G_OPS +-- R_CLI

class "<b>System Management</b>" as R_SYS <<Technical>> {
    Monitor Health, Update Pricing Rules
}
R_CLI +-- R_SYS

class "<b>External Systems</b>" as R_INT <<Technical>> {
    Bank API, Roaming Data Sharing
}
G_OPS +-- R_INT

class "<b>Non-Functional Requirements</b>" as G_NFR <<NonFunctional>>
ROOT +-- G_NFR

class "<b>Security & Privacy</b>" as R_SEC <<NonFunctional>> {
    GDPR, Password Hashing
    Tokenized Payments (PCI-DSS)
}
G_NFR +-- R_SEC

class "<b>Performance</b>" as R_PERF <<NonFunctional>> {
    App Load < 2s
    1000 Concurrent Users
}
G_NFR +-- R_PERF

class "<b>Reliability & Access</b>" as R_REL <<NonFunctional>> {
    99.9% Uptime (Availability)
    Low Signal Mode Support
}
G_NFR +-- R_REL

class "<b>Supported Platforms</b>" as R_PLAT <<NonFunctional>> {
    Web, Smartphone App, CLI
}
G_NFR +-- R_PLAT

@enduml


Use Case 1
@startuml
title UC1: Search & Route to Charging Station

actor "Πελάτης\n(EV Driver)" as User
participant "Mobile/Web App" as App
participant "Backend Service" as BE
database "Βάση Δεδομένων\nΦορτιστών (DB)" as DB
participant "Maps Service\n(e.g. Google Maps API)" as Maps
participant "Navigation App\n(External)" as Nav

== Open Map & Apply Filters ==

User -> App: Open map / Nearby chargers view
App -> BE: GET /chargers/nearby\n(location, filters:\nplugType, minPower, availability)

BE -> DB: queryChargers(location, filters)
DB --> BE: chargerList

alt No chargers found
  BE --> App: NoResults("No chargers match filters")
  App --> User: Show message:\n"No stations found, relax filters?"
else Chargers found
  BE --> App: chargerListWithAvailability
  App --> User: Show chargers on map\n(with real-time status)
end

== Select Station & View Details ==

User -> App: Tap charger marker\n(on the map)
App -> BE: GET /chargers/{chargerId}/details

BE -> DB: getChargerDetails(chargerId)
DB --> BE: chargerDetails\n(location, power, connectors,\npricing, liveAvailability)

BE --> App: chargerDetails\n(+ distance, ETA if computed)
App --> User: Show charger details\n(distance, ETA, status, power, plug types)

== Start Navigation ==

User -> App: Press "Navigate" button
App -> Maps: requestRoute(startLocation,\nchargerLocation)

alt Maps service returns route
  Maps --> App: routeData\n(steps, ETA, distance,\n deeplink/url)
  App -> Nav: openNavigation(routeDeeplink)
  Nav --> User: Start turn-by-turn navigation
else Maps error / no route
  Maps --> App: error("Route unavailable")
  App --> User: Show error\n"Unable to start navigation"
end

@enduml


Use Case 2
@startuml
title UC2: View and Reserve Charger

actor "Πελάτης\n(EV Driver)" as User
participant "Mobile/Web App" as App
participant "Backend Service\n(Charging Network)" as BE
database "Βάση Δεδομένων\nΦορτιστών (DB)" as DB
participant "Pricing Engine\n(Dynamic Tariffs)" as PE

== Request Charger List / Map ==

User -> App: Open chargers list / map\n(or refresh view)
App -> BE: GET /chargers/nearby\n(location, filters)

BE -> DB: queryChargersWithStatus(location, filters)
DB --> BE: chargerList(status, basePricing)

BE -> PE: applyDynamicPricing(chargerList,\n contextParams)
PE --> BE: chargerListWithDynamicPricing

BE --> App: chargerList(status, dynamicPricing)
App --> User: Show chargers on map/list\n(status, dynamic price per kWh)

== Select Charger & Request Reservation ==

User -> App: Select charger & press "Reserve"
App -> BE: POST /reservations\n(userId, chargerId, desiredWindow)

BE -> DB: checkAvailability(chargerId, desiredWindow)
DB --> BE: available / notAvailable

alt Charger not available
  BE --> App: ReservationFailed("Charger not available")
  App --> User: Show message:\n"Charger busy, pick another"
else Charger available
  BE -> DB: createReservation(userId, chargerId,\n startTime, expirationTime,\n status="ACTIVE")
  DB --> BE: reservationId, expirationTime

  BE --> App: ReservationConfirmed(reservationId,\n chargerId, expirationTime)
  App --> User: Show confirmation screen\n+ countdown timer (e.g. 30 min)
end

== Reservation Countdown ==

loop While reservation active\n(until expiration or session start)
  App -> App: Update countdown timer UI
end

== Reservation Expiry or Use ==

alt Reservation expires before use
  BE -> DB: autoExpireReservations(now)
  DB --> BE: expiredReservations
  BE --> App: ReservationExpired(reservationId)
  App --> User: Show "Reservation expired"\nCharger released
else User arrives and starts charging
  note right
    Starting the charging session\nis handled in UC3:
    "Start and Complete\nCharging Session"
  end note
end

@enduml


Use Case 3
@startuml
title UC3: Start and Monitor Charging Session

actor "Πελάτης\n(EV Driver)" as User
participant "Mobile/Web App" as App
participant "Backend Service" as BE
participant "Payment Provider" as Pay
participant "Charger\n(HW Controller)" as Charger
database "Database" as DB
participant "Pricing Engine" as PE

== Start Charging Request ==

User -> App: Press "Start Charging"\n(on selected charger)
App -> BE: POST /sessions/start\n(userId, chargerId, reservationId?,\n paymentMethod, preAuthAmount)

BE -> DB: validateChargerOrReservation(userId,\n chargerId, reservationId)
DB --> BE: chargerAvailable / notAvailable

alt Charger not available
  BE --> App: SessionStartFailed("Charger not available")
  App --> User: Show error\n"Charger busy or reservation invalid"
else Charger available
  == Pre-Authorization ==
  BE -> Pay: createPreAuthorization(preAuthAmount,\n paymentMethod)
  Pay --> BE: PreAuthResult(approved/declined, authId)

  alt Pre-authorization declined
    BE --> App: SessionStartFailed("Payment pre-auth declined")
    App --> User: Show payment error\nand retry instructions
  else Pre-authorization approved
    BE -> Charger: startCharging(chargerId, sessionParams)
    Charger --> BE: chargingStarted()
    BE -> DB: createSession(userId, chargerId,\n reservationId?, authId,\n startTime, status="ACTIVE")
    BE --> App: SessionStarted(sessionId)
    App --> User: Show charging screen\n(with live progress)
  end
end

== Charging Progress ==

loop Periodic status updates\n(e.g. every 10–30s)
  Charger -> BE: statusUpdate(sessionId,\n kWhDelivered, chargingTime,\n batterySoC)
  BE -> PE: calculateCurrentCost(kWhDelivered,\n tariffParams)
  PE --> BE: currentCost
  BE --> App: updateProgress(sessionId,\n kWhDelivered, chargingTime,\n batterySoC, currentCost)
  App --> User: Update UI\n(kWh, time, cost)
end

== Stop Conditions ==

alt User stops charging
  User -> App: Press "Stop Charging"
  App -> BE: POST /sessions/stop(sessionId)
  BE -> Charger: stopCharging(sessionId)
  Charger --> BE: chargingStopped(finalKWh)
else Battery full auto-stop
  Charger -> BE: batteryFull(sessionId, finalKWh)
else Pre-authorized amount limit reached
  BE -> Charger: stopCharging(sessionId)
  Charger --> BE: chargingStopped(finalKWh)
else Hardware / connection error
  Charger --> BE: errorStatus(sessionId, errorCode)
  BE --> App: SessionError(errorCode,\n "Hardware/connection issue")
  App --> User: Show error and\nretry / support instructions
end

== Final Billing ==

BE -> PE: calculateFinalCost(finalKWh, tariffParams)
PE --> BE: finalCost

BE -> Pay: capturePayment(authId, finalCost)
Pay --> BE: paymentCaptured(success/failure)

alt Payment success
  BE -> Pay: releaseRemaining(authId,\n preAuthAmount - finalCost)
  BE -> DB: updateSession(sessionId,\n endTime, finalKWh,\n finalCost, status="COMPLETED")
  BE --> App: SessionCompleted(sessionId,\n finalKWh, finalCost, receiptData)
  App --> User: Show receipt\nand session summary
else Payment failure
  BE -> DB: updateSession(sessionId,\n status="PAYMENT_FAILED")
  BE --> App: PaymentError("Issue capturing payment")
  App --> User: Show error and\nsupport contact info
end

@enduml

Use Case 4
@startuml
title UC4: View Billing and Usage History

actor "Πελάτης\n(EV Driver)" as User
participant "Mobile/Web App" as App
participant "Backend Service" as BE
database "Database\n(Sessions & Invoices)" as DB
participant "Billing System\n(Pricing/Invoices)" as Bill

== Open History Section (Default Period) ==

User -> App: Open "Χρεώσεις / Ιστορικό" screen
App -> BE: GET /history\n(userId, period=last6months)

BE -> DB: fetchSessionsAndInvoices(userId,\n period=last6months)
DB --> BE: sessionList

alt No records found
  BE --> App: HistoryData([])\n(noRecords=true)
  App --> User: Show message\n"Δεν υπάρχει ιστορικό"
else Records found
  BE -> Bill: enrichWithBilling(sessionList)
  Bill --> BE: billingDetails\n(kWh, cost, totals, taxes)

  BE --> App: HistoryData(billingDetails)
  App --> User: Show list of sessions,\nenergy usage & totals\n(default last 6 months)
end

== User Selects Custom Period ==

User -> App: Select custom date range\n(fromDate, toDate)
App -> BE: GET /history\n(userId, fromDate, toDate)

alt Network / backend error
  BE --> App: Error("Network or server error")
  App --> User: Show error\n"Πρόβλημα σύνδεσης, δοκιμάστε ξανά"
else Request processed
  BE -> DB: fetchSessionsAndInvoices(userId,\n fromDate, toDate)
  DB --> BE: sessionListFiltered

  alt No records in selected period
    BE --> App: HistoryData([])\n(noRecords=true)
    App --> User: Show message\n"Δεν υπάρχει ιστορικό"
  else Records found
    BE -> Bill: enrichWithBilling(sessionListFiltered)
    Bill --> BE: billingDetailsFiltered

    BE --> App: HistoryData(billingDetailsFiltered)
    App --> User: Show updated list,\nusage charts & totals\n(for selected period)
  end
end

== Download Reports (PDF/Excel) ==

User -> App: Click "Download Report"\n(select PDF or Excel)
App -> BE: GET /history/report\n(userId, fromDate, toDate, format)

BE -> Bill: generateReport(userId,\n fromDate, toDate, format)
Bill --> BE: reportFile / downloadToken

BE --> App: ReportReady(downloadLink)
App --> User: Trigger file download\n(PDF/Excel report)

@enduml